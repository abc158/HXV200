//  Copyright (C) 2016-2020, Amicro, Inc.
//  permission of Amicro, Inc.  All rights reserved.
#ifndef _DOCK_IR_SIGNAL_H_
#define _DOCK_IR_SIGNAL_H_

extern void ir_send(void);

#endif //_DOCK_IR_SIGNAL_H_